import xbmc
import xbmcgui
import xbmcaddon
import os
import urllib.request
import zipfile

ADDON = xbmcaddon.Addon()
BUILD_URL = 'https://www.dropbox.com/scl/fi/pje7qzcclm461o3z7jxwm/Mybuild.zip?rlkey=yxk3dfpx6h9z6vg3xgijxha28&st=tbjyotrp&dl=1'
BUILD_ZIP = os.path.join(xbmc.translatePath('special://home/addons/'), 'Mybuild.zip')
BUILD_EXTRACT_PATH = xbmc.translatePath('special://home/')

def download_build():
    dialog = xbmcgui.DialogProgress()
    dialog.create("Meta Tech Wizard", "Downloading your build...")
    urllib.request.urlretrieve(BUILD_URL, BUILD_ZIP)
    dialog.close()

def install_build():
    if os.path.exists(BUILD_ZIP):
        with zipfile.ZipFile(BUILD_ZIP, 'r') as zip_ref:
            zip_ref.extractall(BUILD_EXTRACT_PATH)
        os.remove(BUILD_ZIP)
        xbmcgui.Dialog().ok("Build Installed", "Kodi will now restart.")
        xbmc.executebuiltin('Quit()')

if __name__ == '__main__':
    download_build()
    install_build()
